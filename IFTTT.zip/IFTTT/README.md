[Jibo SDK & API Documentation](https://developers.jibo.com/sdk/docs/)
